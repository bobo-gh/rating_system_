import request from '../../utils/request'
import config from '../../config'

Page({
  data: {
    groups: [],
    loading: true,
    userInfo: null
  },

  onLoad() {
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }

    this.setData({
      userInfo: app.globalData.userInfo
    });
    this.fetchGroups();
  },

  onShow() {
    const app = getApp();
    if (!app.globalData.isLoggedIn) {
      wx.reLaunch({
        url: '/pages/login/login'
      });
      return;
    }
    // 每次显示页面时刷新数据
    this.fetchGroups();
  },

  // 获取分组列表
  async fetchGroups() {
    this.setData({ loading: true });
    try {
      console.log('开始获取分组列表...');
      const res = await request(config.api.groups);
      console.log('获取到的分组数据:', res.data);
      
      this.setData({
        groups: res.data,
        loading: false
      });
      
      console.log('当前页面数据:', this.data);
    } catch (error) {
      console.error('获取分组失败:', error);
      if (error.code === 401) {
        // token失效，登出并跳转到登录页
        const app = getApp();
        app.logout();
      } else {
        wx.showToast({
          title: error.msg || '获取分组失败',
          icon: 'none'
        });
      }
      this.setData({ loading: false });
    }
  },

  // 跳转到评分页面
  goToRate(e) {
    console.log('点击分组，事件数据:', e);
    const { groupId } = e.currentTarget.dataset;
    console.log('准备跳转到分组:', groupId);
    
    if (!groupId) {
      console.error('未获取到分组ID');
      wx.showToast({
        title: '分组信息错误',
        icon: 'none'
      });
      return;
    }

    wx.navigateTo({
      url: `/pages/rate/rate?groupId=${groupId}`,
      fail: (err) => {
        console.error('页面跳转失败:', err);
        wx.showToast({
          title: '页面跳转失败',
          icon: 'none'
        });
      }
    });
  },

  // 退出登录
  logout() {
    wx.showModal({
      title: '提示',
      content: '确定要退出登录吗？',
      success: (res) => {
        if (res.confirm) {
          const app = getApp();
          app.logout();
        }
      }
    });
  }
}); 