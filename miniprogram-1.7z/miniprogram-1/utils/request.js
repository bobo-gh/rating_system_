import config from '../config';

const request = (url, options = {}) => {
  return new Promise((resolve, reject) => {
    // 获取存储的token
    const token = wx.getStorageSync('token');
    console.log('请求URL:', `${config.baseUrl}${url}`);
    console.log('请求方法:', options.method || 'GET');
    console.log('当前Token:', token);

    const header = {
      'Content-Type': 'application/json'
    };

    // 如果有token，添加到Authorization头中
    if (token) {
      header.Authorization = `Bearer ${token}`;
    }

    console.log('请求头:', header);
    
    wx.request({
      url: `${config.baseUrl}${url}`,
      method: options.method || 'GET',
      data: options.data,
      header,
      success: (res) => {
        console.log('响应数据:', res);
        if (res.statusCode === 200) {
          if (res.data.code === 0) {
            resolve(res.data);
          } else {
            reject(res.data);
          }
        } else if (res.statusCode === 401) {
          console.log('Token无效，清除登录状态');
          // token失效，跳转到登录页
          wx.removeStorageSync('token');
          wx.removeStorageSync('userInfo');
          const app = getApp();
          app.logout();
          reject({ msg: '请重新登录' });
        } else {
          reject(res.data || { msg: '请求失败' });
        }
      },
      fail: (err) => {
        console.error('请求失败:', err);
        reject({ msg: '网络请求失败' });
      }
    });
  });
};

export default request;
