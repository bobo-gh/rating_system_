const config = {
  // API接口基础路径 - 本地开发环境
  baseUrl: 'http://localhost:4262/api',  // 注意这里不要加末尾斜杠

  // API路由
  api: {
    login: '/login',
    groups: '/groups',
    members: '/members',
    score: '/score'
  }
}

export default config 