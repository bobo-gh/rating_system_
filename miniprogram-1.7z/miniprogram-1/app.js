// app.js
App({
  globalData: {
    userInfo: null,
    isLoggedIn: false,
    token: null
  },

  onLaunch() {
    // 检查登录状态
    const token = wx.getStorageSync('token');
    const userInfo = wx.getStorageSync('userInfo');
    
    console.log('启动时检查 - Token:', token); // 添加日志
    console.log('启动时检查 - UserInfo:', userInfo); // 添加日志
    
    if (token && userInfo) {
      this.globalData.isLoggedIn = true;
      this.globalData.userInfo = userInfo;
      this.globalData.token = token;
      console.log('已恢复登录状态'); // 添加日志
    } else {
      // 清除可能存在的无效数据
      this.clearLoginState();
    }
  },

  // 登录成功后调用
  login(token, userInfo) {
    console.log('设置登录状态 - Token:', token); // 添加日志
    console.log('设置登录状态 - UserInfo:', userInfo); // 添加日志
    
    this.globalData.isLoggedIn = true;
    this.globalData.userInfo = userInfo;
    this.globalData.token = token;
    
    wx.setStorageSync('token', token);
    wx.setStorageSync('userInfo', userInfo);
  },

  // 清除登录状态
  clearLoginState() {
    console.log('清除登录状态'); // 添加日志
    this.globalData.isLoggedIn = false;
    this.globalData.userInfo = null;
    this.globalData.token = null;
    wx.removeStorageSync('token');
    wx.removeStorageSync('userInfo');
  },

  // 登出
  logout() {
    this.clearLoginState();
    wx.reLaunch({
      url: '/pages/login/login'
    });
  }
}); 